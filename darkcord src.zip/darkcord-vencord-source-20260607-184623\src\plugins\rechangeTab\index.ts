import definePlugin, { StartAt } from "@utils/types";

const DARKCORD_ICON = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 128 128'%3E%3Crect width='128' height='128' fill='%23070707'/%3E%3Ccircle cx='64' cy='64' r='58' fill='%23151515'/%3E%3Ctext x='64' y='88' text-anchor='middle' font-family='Arial,sans-serif' font-size='76' font-weight='700' fill='%23676767'%3ED%3C/text%3E%3C/svg%3E";
let originalTitle = "";
let originalIcons: HTMLLinkElement[] = [];
let timer: number | undefined;

function setDarkcordTab() {
    if (!/^\(\+\d{1,2}\)\s+Darkcord$/.test(document.title)) {
        document.title = "Darkcord";
    }

    document.querySelectorAll<HTMLLinkElement>("link[rel~='icon'], link[rel='shortcut icon'], link[rel='apple-touch-icon']")
        .forEach(link => link.remove());

    const icon = document.createElement("link");
    icon.rel = "icon";
    icon.href = DARKCORD_ICON;
    icon.type = "image/svg+xml";
    document.head.append(icon);
}

function restoreTab() {
    window.clearInterval(timer);
    timer = undefined;
    document.title = originalTitle || "Discord";
    document.querySelectorAll<HTMLLinkElement>("link[rel~='icon'], link[rel='shortcut icon'], link[rel='apple-touch-icon']")
        .forEach(link => link.remove());
    originalIcons.forEach(link => document.head.append(link));
}

export default definePlugin({
    name: "RechangeTab",
    description: "Changes the Discord tab title and icon to Darkcord.",
    tags: ["Utility"],
    authors: [{ name: "Darkcord" }],
    startAt: StartAt.DOMContentLoaded,
    start() {
        originalTitle = document.title;
        originalIcons = [...document.querySelectorAll<HTMLLinkElement>("link[rel~='icon'], link[rel='shortcut icon'], link[rel='apple-touch-icon']")]
            .map(link => link.cloneNode(true) as HTMLLinkElement);
        setDarkcordTab();
        timer = window.setInterval(setDarkcordTab, 1500);
    },
    stop: restoreTab
});
