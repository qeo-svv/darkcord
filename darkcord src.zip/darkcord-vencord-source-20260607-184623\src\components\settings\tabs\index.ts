/*
 * Vencord, a Discord client mod
 * Copyright (c) 2025 Vendicated and contributors
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

import "./styles.css";

export * from "./BaseTab";
export { default as PluginsTab } from "./plugins";
export { openPluginModal } from "./plugins/PluginModal";
export { default as DarkcordTab } from "./vencord";
