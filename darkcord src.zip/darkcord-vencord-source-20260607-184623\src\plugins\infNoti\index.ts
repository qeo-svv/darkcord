import { definePluginSettings } from "@api/Settings";
import definePlugin, { OptionType, StartAt } from "@utils/types";

const settings = definePluginSettings({
    enabledOnStart: {
        type: OptionType.BOOLEAN,
        description: "Start the fake tab counter automatically",
        default: true
    }
});

let timer: number | undefined;
let count = 0;

function setTitle() {
    document.title = `(+${count}) Darkcord`;
}

function startCounter() {
    if (timer) return;
    setTitle();
    timer = window.setInterval(() => {
        count = count >= 99 ? 0 : count + 1;
        setTitle();
    }, 1000);
}

function stopCounter() {
    window.clearInterval(timer);
    timer = undefined;
    document.title = "Darkcord";
}

export default definePlugin({
    name: "InfNoti",
    description: "Loops a fake Darkcord tab notification counter from (+0) to (+99).",
    tags: ["Utility"],
    authors: [{ name: "Darkcord" }],
    startAt: StartAt.DOMContentLoaded,
    settings,
    toolboxActions: {
        "Toggle InfNoti": () => timer ? stopCounter() : startCounter()
    },
    start() {
        if (settings.store.enabledOnStart) startCounter();
    },
    stop: stopCounter
});
