import definePlugin from "@utils/types";
import { Button, Forms, Modal, openModal, React, showToast, Toasts, useEffect, useState } from "@webpack/common";
import type { RenderModalProps } from "@vencord/discord-types";

import gitHash from "~git-hash";

const REPO = "Darkcord/Darkcord";
const REPO_URL = `https://github.com/${REPO}`;
const LATEST_COMMIT_URL = `https://api.github.com/repos/${REPO}/commits/main`;
const RECENT_COMMITS_URL = `https://api.github.com/repos/${REPO}/commits?per_page=5`;
const SOURCE_ZIP_URL = `${REPO_URL}/archive/refs/heads/main.zip`;
const RELEASES_URL = `${REPO_URL}/releases/latest`;
const LAST_SEEN_KEY = "DarkcordUpdater:lastSeenSha";

const LOCAL_CHANGELOG = [
    "Added the Darkcord updater check and what-new modal.",
    "Added CustomTheme image/GIF backgrounds.",
    "Kept FakeNitro, CustomRPC, MessageLogger, ILoveSpam, InfNoti, RechangeTab, and CustomTheme.",
    "Removed donation, contributor, and old Themes settings surfaces."
];

interface GitHubCommit {
    sha: string;
    html_url?: string;
    commit?: {
        message?: string;
        author?: {
            date?: string;
        };
    };
}

interface UpdateInfo {
    ok: boolean;
    latestSha?: string;
    latestUrl?: string;
    updateAvailable: boolean;
    commits: GitHubCommit[];
    error?: string;
}

function isDifferentBuild(latestSha?: string) {
    if (!latestSha) return false;

    const current = gitHash.toLowerCase();
    const latest = latestSha.toLowerCase();

    return !latest.startsWith(current) && !current.startsWith(latest.slice(0, 7));
}

async function fetchGitHub<T>(url: string): Promise<T> {
    const response = await fetch(url, {
        headers: {
            Accept: "application/vnd.github+json"
        }
    });

    if (!response.ok) {
        throw new Error(`GitHub returned ${response.status}`);
    }

    return response.json();
}

async function checkForUpdates(): Promise<UpdateInfo> {
    try {
        const latest = await fetchGitHub<GitHubCommit>(LATEST_COMMIT_URL);
        const commits = await fetchGitHub<GitHubCommit[]>(RECENT_COMMITS_URL);

        return {
            ok: true,
            latestSha: latest.sha,
            latestUrl: latest.html_url,
            updateAvailable: isDifferentBuild(latest.sha),
            commits
        };
    } catch (error) {
        return {
            ok: false,
            updateAvailable: false,
            commits: [],
            error: error instanceof Error ? error.message : String(error)
        };
    }
}

function openExternal(url: string) {
    VencordNative.native.openExternal(url);
}

function CommitList({ commits }: { commits: GitHubCommit[]; }) {
    if (!commits.length) {
        return <Forms.FormText>No remote commits could be loaded.</Forms.FormText>;
    }

    return (
        <ul style={{ margin: "8px 0 0", paddingLeft: 20 }}>
            {commits.map(commit => (
                <li key={commit.sha}>
                    <Forms.FormText>
                        {(commit.commit?.message ?? "Untitled commit").split("\n")[0]}{" "}
                        <span style={{ color: "var(--text-muted)" }}>
                            ({commit.sha.slice(0, 7)})
                        </span>
                    </Forms.FormText>
                </li>
            ))}
        </ul>
    );
}

function UpdateModal({ transitionState, onClose }: RenderModalProps) {
    const [info, setInfo] = useState<UpdateInfo | null>(null);
    const [checking, setChecking] = useState(true);

    async function refresh() {
        setChecking(true);
        const next = await checkForUpdates();
        setInfo(next);
        setChecking(false);

        if (next.latestSha) {
            localStorage.setItem(LAST_SEEN_KEY, next.latestSha);
        }
    }

    useEffect(() => {
        refresh();
    }, []);

    const statusText = checking
        ? "Checking GitHub for Darkcord updates..."
        : info?.ok
            ? info.updateAvailable
                ? `Update available: ${info.latestSha?.slice(0, 7)}`
                : `Darkcord is up to date with ${gitHash}.`
            : `Update check failed: ${info?.error ?? "Unknown error"}`;

    return (
        <Modal
            transitionState={transitionState}
            onClose={onClose}
            size="lg"
            title="Darkcord Updates"
        >
            <div style={{ display: "grid", gap: 16 }}>
                <Forms.FormText>{statusText}</Forms.FormText>

                <section>
                    <Forms.FormTitle tag="h5">What's New In This Build</Forms.FormTitle>
                    <ul style={{ margin: "8px 0 0", paddingLeft: 20 }}>
                        {LOCAL_CHANGELOG.map(item => (
                            <li key={item}>
                                <Forms.FormText>{item}</Forms.FormText>
                            </li>
                        ))}
                    </ul>
                </section>

                <section>
                    <Forms.FormTitle tag="h5">Latest GitHub Changes</Forms.FormTitle>
                    <CommitList commits={info?.commits ?? []} />
                </section>

                <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
                    <Button onClick={refresh} disabled={checking}>
                        Check Again
                    </Button>
                    <Button onClick={() => openExternal(REPO_URL)}>
                        Open Repository
                    </Button>
                    <Button onClick={() => openExternal(RELEASES_URL)}>
                        Open Latest Release
                    </Button>
                    <Button onClick={() => openExternal(SOURCE_ZIP_URL)}>
                        Download Latest Source
                    </Button>
                </div>
            </div>
        </Modal>
    );
}

export function openDarkcordUpdateModal() {
    openModal(props => <UpdateModal {...props} />);
}

export default definePlugin({
    name: "DarkcordUpdater",
    description: "Checks GitHub for Darkcord updates and shows what changed.",
    authors: [{ name: "Darkcord" }],
    required: true,

    toolboxActions: {
        "Check For Darkcord Updates": openDarkcordUpdateModal
    },

    async start() {
        const info = await checkForUpdates();
        if (!info.ok || !info.updateAvailable || !info.latestSha) return;

        const lastSeen = localStorage.getItem(LAST_SEEN_KEY);
        if (lastSeen === info.latestSha) return;

        localStorage.setItem(LAST_SEEN_KEY, info.latestSha);
        showToast(`Darkcord update available (${info.latestSha.slice(0, 7)})`, Toasts.Type.SUCCESS);
    },

    openUpdateModal: openDarkcordUpdateModal,
    checkForUpdates
});
