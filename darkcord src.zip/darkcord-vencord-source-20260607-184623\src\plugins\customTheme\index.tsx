import { definePluginSettings } from "@api/Settings";
import definePlugin, { OptionType, StartAt } from "@utils/types";
import { Forms, React, showToast } from "@webpack/common";

const STYLE_ID = "darkcord-custom-theme-style";

function applyCustomTheme() {
    let style = document.getElementById(STYLE_ID) as HTMLStyleElement | null;
    const image = settings.store.backgroundDataUrl;

    if (!image) {
        style?.remove();
        document.body.classList.remove("darkcord-custom-theme");
        return;
    }

    if (!style) {
        style = document.createElement("style");
        style.id = STYLE_ID;
        document.head.append(style);
    }

    document.body.classList.add("darkcord-custom-theme");
    style.textContent = `
        body.darkcord-custom-theme {
            --darkcord-custom-bg: url("${image}");
            --darkcord-panel-opacity: ${settings.store.panelOpacity};
            background: #050505 var(--darkcord-custom-bg) center / cover fixed no-repeat !important;
        }
        body.darkcord-custom-theme #app-mount,
        body.darkcord-custom-theme [class*="appMount_"],
        body.darkcord-custom-theme [class*="app_"],
        body.darkcord-custom-theme [class*="bg_"] {
            background: transparent !important;
        }
        body.darkcord-custom-theme [class*="guilds_"] {
            background: rgba(0, 0, 0, 0.78) !important;
        }
        body.darkcord-custom-theme [class*="sidebar_"],
        body.darkcord-custom-theme [class*="chat_"],
        body.darkcord-custom-theme [class*="container_"],
        body.darkcord-custom-theme [class*="content_"],
        body.darkcord-custom-theme [class*="panels_"] {
            background-color: rgba(0, 0, 0, var(--darkcord-panel-opacity)) !important;
        }
    `;
}

function BackgroundUploader() {
    const current = settings.use(["backgroundDataUrl", "panelOpacity"]);

    return (
        <div style={{ display: "grid", gap: 12 }}>
            <Forms.FormText>
                Upload an image or GIF to use as the Discord background. The server list stays visible.
            </Forms.FormText>
            <input
                type="file"
                accept="image/*,.gif"
                onChange={event => {
                    const file = event.currentTarget.files?.[0];
                    if (!file) return;
                    const reader = new FileReader();
                    reader.onload = () => {
                        settings.store.backgroundDataUrl = String(reader.result ?? "");
                        applyCustomTheme();
                        showToast("Darkcord background applied");
                    };
                    reader.readAsDataURL(file);
                }}
            />
            <button
                type="button"
                onClick={() => {
                    settings.store.backgroundDataUrl = "";
                    applyCustomTheme();
                    showToast("Darkcord background cleared");
                }}
            >
                Clear background
            </button>
            <Forms.FormText>
                Current background: {current.backgroundDataUrl ? "uploaded" : "none"}
            </Forms.FormText>
        </div>
    );
}

const settings = definePluginSettings({
    backgroundDataUrl: {
        type: OptionType.CUSTOM,
        default: ""
    },
    uploadBackground: {
        type: OptionType.COMPONENT,
        component: BackgroundUploader
    },
    panelOpacity: {
        type: OptionType.SLIDER,
        description: "Panel darkness",
        default: 0.72,
        markers: [0.35, 0.5, 0.72, 0.9],
        stickToMarkers: false,
        onChange: applyCustomTheme
    }
});

export default definePlugin({
    name: "CustomTheme",
    description: "Upload an image or GIF to use as a Discord background without hiding servers.",
    tags: ["Customisation"],
    authors: [{ name: "Darkcord" }],
    startAt: StartAt.DOMContentLoaded,
    settings,
    start: applyCustomTheme,
    stop() {
        document.getElementById(STYLE_ID)?.remove();
        document.body.classList.remove("darkcord-custom-theme");
    }
});
